package com.myproject.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.myproject.beans.LoginBean;
import com.myproject.connection.DatabaseConnectionManager;

public class LoginDAO {
	static ResultSet resultSet = null;
	static Connection connection = null;

	public static LoginBean validateUser(LoginBean bean) {

		Statement statement = null;

		String username = bean.getUname();
		String password = bean.getPass();

		String searchQuery = "select * from login_information"
				+ " where username='" + username
				+ "' AND password='" + password + "'";
		try {
			connection = DatabaseConnectionManager.getDatabseConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(searchQuery);
			boolean hasMoreRows = resultSet.next();

			if (!hasMoreRows) {
				bean.setValid(false);
			}
			else if (hasMoreRows) {
				String type= resultSet.getString("role");
				String lName = resultSet.getString("lastName");
				String fName = resultSet.getString("firstName");
				bean.setValid(true);
				bean.setRole(type);
				bean.setfName(fName);
				bean.setlName(lName);
			}
		}
		catch (Exception ex) {
			System.out.println("Error Login "
					+ ex);
		}
		finally {
			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (Exception e) {
				}
				resultSet = null;
			}

			if (statement != null) {
				try {
					statement.close();
				} catch (Exception e) {
				}
				statement = null;
			}

			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e) {
				}
				connection = null;
			}
		}
		return bean;

	}
}
