package com.myproject.servlets;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myproject.beans.LoginBean;

/**
 * Servlet implementation class LogoutServlet
 */

public class SignOutServlet extends HttpServlet {

	public void doPost(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
			throws ServletException, java.io.IOException {

		try {
			HttpSession session = httpRequest.getSession(true);
			if ((LoginBean) session.getAttribute("user") != null)
				session.removeAttribute("user");

			httpResponse.sendRedirect("LoginPage.jsp"); // Login page
		}
		catch (Throwable theException) {
			theException.printStackTrace();
		}
	}
}
