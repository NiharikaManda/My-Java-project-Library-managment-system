package com.myproject.servlets;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myproject.beans.LoginBean;
import com.myproject.connection.DatabaseConnectionManager;

public class PatientServlet extends HttpServlet {
	static Connection currentCon = null;
	static ResultSet rs = null;
	Statement stmt = null;
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
			throws ServletException, java.io.IOException {

		try {
			if (httpRequest.getParameter("logout") != null) {
				HttpSession session = httpRequest.getSession(true);
				if (session.getAttribute("user") != null)
					session.removeAttribute("user");
				httpResponse.sendRedirect("LoginPage.jsp"); // Login page
			} else if (httpRequest.getParameter("SavePatient") != null) {
				StringBuffer query = new StringBuffer(
						"insert into patient_information (firstname,"
														+ "lastname,"
														+ "age,"
														+ "gender,"
														+ "username,"
														+ "password,"
														+ "email,"
														+ "diagnosis,"
														+ "Medication,"
														+ "height,"
														+ "weight,"
														+ "isActive)"
														+ " values(");
				query.append("'" + httpRequest.getParameter("fname") + "'" + ",");
				query.append("'" + httpRequest.getParameter("lname") + "'" + ",");
				query.append(httpRequest.getParameter("age") + ",");
				query.append("'" + httpRequest.getParameter("gender") + "'" + ",");
				query.append("'" + httpRequest.getParameter("username") + "'" + ",");
				query.append("'" + httpRequest.getParameter("password") + "'" + ",");
				query.append("'" + httpRequest.getParameter("email") + "'" + ",");
				query.append("''" + ",");
				query.append("''" + ",");
				query.append(httpRequest.getParameter("height") + ",");
				query.append(httpRequest.getParameter("weight") + ",");
				query.append("1");
				query.append(1 + ")");

				StringBuffer query2 = new StringBuffer(
						"insert into login_information (username, "
													+ "password, "
													+ "role, "
													+ "firstname,"
													+ "lastname)"
													+ " VALUES(");
				query2.append("'" + httpRequest.getParameter("username") + "'" + ",");
				query2.append("'" + httpRequest.getParameter("password") + "'" + ",");
				query2.append("'Patient'" + ",");
				query2.append("'" + httpRequest.getParameter("fname") + "'" + ",");
				query2.append("'" + httpRequest.getParameter("lname") + "'" + ")");
				System.out.print(query2.toString());
				currentCon = DatabaseConnectionManager.getDatabseConnection();
				stmt = currentCon.createStatement();
				stmt.execute(query.toString());
				stmt.execute(query2.toString());
				httpResponse.sendRedirect("PatientDetailsPage.jsp"); 
			}else if (httpRequest.getParameter("deletePatient") != null) {
				HttpSession session = httpRequest.getSession(true);
				LoginBean user = (LoginBean) session.getAttribute("user");
				StringBuffer query = new StringBuffer("delete from patient_information" + " where firstname like "
						+ "'%" + httpRequest.getParameter("fname") + "%' or lastname like" + "'%"
						+ httpRequest.getParameter("fname") + "%'");
				System.out.println(query.toString());
				
				StringBuffer loginDelteQuery = new StringBuffer("delete from login_information" + " where firstname like "
						+ "'%" + httpRequest.getParameter("fname") + "%' or lastname like" + "'%"
						+ httpRequest.getParameter("fname") + "%'");
				
				currentCon = DatabaseConnectionManager.getDatabseConnection();
				stmt = currentCon.createStatement();
				int n = stmt.executeUpdate(query.toString());
				if(n>0){
					n = stmt.executeUpdate(loginDelteQuery.toString());
					if(n>0) System.out.println("Patient deleted from login table");
					httpResponse.sendRedirect("DeletePatientPage.jsp");
					System.out.println("Patient row deleted sucessfully");
				}else{
					System.out.println("Cannot find a patient who has a given first name or last name");
				}
			} else if (httpRequest.getParameter("ViewDetails") != null) {
				HttpSession session = httpRequest.getSession(true);
				LoginBean user = (LoginBean) session.getAttribute("user");
				StringBuffer query = new StringBuffer(
						"Select * from patient_information where username=" + "'" + user.getUname() + "'");
				System.out.println(query.toString());
				currentCon = DatabaseConnectionManager.getDatabseConnection();
				stmt = currentCon.createStatement();
				rs = stmt.executeQuery(query.toString());
				if (rs.next()) {
					session.setAttribute("firstname", rs.getString("firstname"));
					session.setAttribute("lastname", rs.getString("lastname"));
					session.setAttribute("age", rs.getString("age"));
					session.setAttribute("gender", rs.getString("gender"));
					session.setAttribute("username", rs.getString("username"));
					session.setAttribute("password", rs.getString("password"));
					session.setAttribute("email", rs.getString("email"));
					System.out.println(rs.getString("diagnosis") + "\n" + rs.getString("Medication"));
					session.setAttribute("diagnosis", rs.getString("diagnosis"));
					session.setAttribute("Medication", rs.getString("Medication"));
					session.setAttribute("height", rs.getString("height"));
					session.setAttribute("weight", rs.getString("weight"));
					session.setAttribute("isActive", rs.getString("isActive"));
					httpResponse.sendRedirect(httpRequest.getContextPath() + "/PatientViewDetails.jsp");
				}
			} 
		} catch (Exception ex) {
			System.out.println("Exception" + ex.getMessage());
		}
	}
}