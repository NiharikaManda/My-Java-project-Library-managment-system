package com.myproject.servlets;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdministratorServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, java.io.IOException {

		try {
			if (request.getParameter("logout") != null) {
				HttpSession session = request.getSession(true);
				if (session.getAttribute("user") != null)
					session.removeAttribute("user");
				response.sendRedirect("LoginPage.jsp"); // Login page
			}
			else if (request.getParameter("AddPatient") != null) {
				response.sendRedirect("PatientDetailsPage.jsp"); // Patient Details page
			}
			else if (request.getParameter("AddDoctor") != null) {
				response.sendRedirect("DoctorDetailsPage.jsp"); // Doctor Details page
			}
			else if (request.getParameter("DeleteDoctor") != null) {
				response.sendRedirect("DeleteDoctorPage.jsp"); // Doctor Delete page
			}
			else if (request.getParameter("DeletePatient") != null) {
				response.sendRedirect("DeletePatientPage.jsp"); // Patient Delete page
			}
		}

		catch (Throwable theException) {
			System.out.println(theException);
		}
	}
}