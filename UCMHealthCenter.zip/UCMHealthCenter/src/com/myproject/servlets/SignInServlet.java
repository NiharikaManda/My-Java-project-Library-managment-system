package com.myproject.servlets;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myproject.DAO.LoginDAO;
import com.myproject.beans.LoginBean;


public class SignInServlet extends HttpServlet {

	public void doPost(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
			throws ServletException, java.io.IOException {

		try {
			
			LoginBean user = new LoginBean();
			user.setUname(httpRequest.getParameter("userName"));
			user.setPass(httpRequest.getParameter("password"));

			user = LoginDAO.validateUser(user);

			if (user.isValid()) {
				HttpSession session = httpRequest.getSession(true);
				session.setAttribute("user", user);
				if(user.getRole().equalsIgnoreCase("ADMIN"))
					httpResponse.sendRedirect("AdministratorHomePage.jsp"); // Home page for admin
				else if(user.getRole().equalsIgnoreCase("PATIENT"))
					httpResponse.sendRedirect("PatientHomePage.jsp"); // Home page for patient
				else if(user.getRole().equalsIgnoreCase("DOCTOR"))
					httpResponse.sendRedirect("DoctorHomePage.jsp"); // Home page for Doctor
			}
			else
				httpResponse.sendRedirect("InvalidLoginPage.jsp"); // unauthorized user page
		}

		catch (Throwable theException) {
			System.out.println(theException);
		}
	}
}