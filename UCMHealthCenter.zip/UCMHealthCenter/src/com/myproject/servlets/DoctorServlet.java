package com.myproject.servlets;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myproject.beans.LoginBean;
import com.myproject.connection.DatabaseConnectionManager;

/**
 * Servlet implementation class LoginServlet
 */

public class DoctorServlet extends HttpServlet {
static Connection currentCon = null;
	static ResultSet rs = null;
	Statement stmt = null;

	public void doPost(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
			throws ServletException, java.io.IOException {

		try {
			if (httpRequest.getParameter("SaveDoctor") != null) {
				StringBuffer query = new StringBuffer("INSERT INTO doctor_information (firstName, " + "lastName,"
						+ "username," + "password," + "gender," + "email," + "isActive)  " + "VALUES (");
				query.append("'" + httpRequest.getParameter("fname") + "'" + ",");
				query.append("'" + httpRequest.getParameter("lname") + "'" + ",");
				query.append("'" + httpRequest.getParameter("username") + "'" + ",");
				query.append("'" + httpRequest.getParameter("password") + "'" + ",");
				query.append("'" + httpRequest.getParameter("gender") + "'" + ",");
				query.append("'" + httpRequest.getParameter("email") + "'" + ",");
				query.append(1 + ")");
				System.out.println(query);

				StringBuffer query2 = new StringBuffer("insert into login_information (username, " + "password, "
						+ "role, " + "firstname," + "lastname) " + "VALUES(");
				query2.append("'" + httpRequest.getParameter("username") + "'" + ",");
				query2.append("'" + httpRequest.getParameter("password") + "'" + ",");
				query2.append("'Doctor'" + ",");
				query2.append("'" + httpRequest.getParameter("fname") + "'" + ",");
				query2.append("'" + httpRequest.getParameter("lname") + "'" + ")");
				System.out.print(query2.toString());

				try {
					// connect to DB
					currentCon = DatabaseConnectionManager.getDatabseConnection();
					stmt = currentCon.createStatement();
					stmt.execute(query.toString());
					stmt.execute(query2.toString());
				}

				catch (Exception ex) {
					System.out.println("!!!!! An Exception occurred!!!! " + ex);
				}
				httpResponse.sendRedirect("DoctorDetailsPage.jsp");
			} else if (httpRequest.getParameter("viewPatientDetails") != null) {
				HttpSession session = httpRequest.getSession(true);
				LoginBean user = (LoginBean) session.getAttribute("user");
				StringBuffer query = new StringBuffer("Select * from patient_information" + " where firstname like "
						+ "'%" + httpRequest.getParameter("fname") + "%' or lastname like" + "'%"
						+ httpRequest.getParameter("fname") + "%'");
				System.out.println(query.toString());
				// connect to DB
				currentCon = DatabaseConnectionManager.getDatabseConnection();
				stmt = currentCon.createStatement();
				rs = stmt.executeQuery(query.toString());
				if (rs.next()) {
					System.out.println(rs.getString("Medication"));
					session.setAttribute("firstname", rs.getString("firstname"));
					session.setAttribute("lastname", rs.getString("lastname"));
					session.setAttribute("age", rs.getString("age"));
					session.setAttribute("gender", rs.getString("gender"));
					session.setAttribute("username", rs.getString("username"));
					session.setAttribute("password", rs.getString("password"));
					session.setAttribute("email", rs.getString("email"));
					session.setAttribute("diagnosis", rs.getString("diagnosis"));
					session.setAttribute("Medication", rs.getString("Medication"));
					session.setAttribute("height", rs.getString("height"));
					session.setAttribute("weight", rs.getString("weight"));
					session.setAttribute("isActive", rs.getString("isActive"));
					httpResponse.sendRedirect(httpRequest.getContextPath() + "/DoctorViewPatientDetailsPage.jsp");
				}
			} else if (httpRequest.getParameter("SavePatient") != null) {
				HttpSession session = httpRequest.getSession(true);
				LoginBean user = (LoginBean) session.getAttribute("user");
				System.out.println(user.getUname());
				StringBuffer query = new StringBuffer("update patient_information set medication=" + "'"
						+ httpRequest.getParameter("medications") + "', ");
				query.append("diagnosis ='" + httpRequest.getParameter("diagnosis") + "'" + "where firstname like '%"
						+ httpRequest.getParameter("firstname") + "%'");
				System.out.println(query);
				currentCon = DatabaseConnectionManager.getDatabseConnection();
				stmt = currentCon.createStatement();
				int n = stmt.executeUpdate(query.toString());
				if (n > 0) {
					System.out.println("rows updated sucessfully");
				}
				httpResponse.sendRedirect(httpRequest.getContextPath() + "/DoctorHomePage.jsp");
			} else if (httpRequest.getParameter("deleteDoctor") != null) {
				HttpSession session = httpRequest.getSession(true);
				LoginBean user = (LoginBean) session.getAttribute("user");
				StringBuffer query = new StringBuffer("delete from doctor_information" + " where firstname like " + "'%"
						+ httpRequest.getParameter("fname") + "%' or lastname like" + "'%"
						+ httpRequest.getParameter("fname") + "%'");
				System.out.println(query.toString());
				// connect to DB

				StringBuffer loginDelteQuery = new StringBuffer("delete from login_information"
						+ " where firstname like " + "'%" + httpRequest.getParameter("fname") + "%' or lastname like"
						+ "'%" + httpRequest.getParameter("fname") + "%'");
				currentCon = DatabaseConnectionManager.getDatabseConnection();
				stmt = currentCon.createStatement();
				int n = stmt.executeUpdate(query.toString());
				if (n > 0) {
					n = stmt.executeUpdate(loginDelteQuery.toString());
					if (n > 0)
						System.out.println("Doctor deleted from login table");
					httpResponse.sendRedirect("DeleteDoctorPage.jsp");
					System.out.println("Doctor row deleted sucessfully");
				} else {
					System.out.println("Cannot find a doctor who has a given first name or last name");
				}
			} else if (httpRequest.getParameter("logout") != null) {
				HttpSession session = httpRequest.getSession(true);
				if (session.getAttribute("user") != null)
					session.removeAttribute("user");
				httpResponse.sendRedirect("LoginPage.jsp"); // Login page
			}
		} catch (Throwable theException) {
			System.out.println(theException);
		}
	}
}