package com.myproject.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnectionManager {
	
	static String dataBaseUrl;
	static Connection databaseConnection;

	public static Connection getDatabseConnection() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/UCMHealthCenter";
			try {
				databaseConnection = DriverManager.getConnection(url, "root", "root");
			}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		}

		catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		return databaseConnection;
	}
}